from flask import Flask, request, render_template, redirect, url_for
import os
from PyPDF2 import PdfReader
from docx import Document

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Function to extract text from PDF
def extract_pdf_text(file_path):
    with open(file_path, 'rb') as f:
        reader = PdfReader(f)
        text = ''
        for page in reader.pages:
            text += page.extract_text()
    return text

# Function to extract text from DOCX
def extract_docx_text(file_path):
    doc = Document(file_path)
    text = ''
    for para in doc.paragraphs:
        text += para.text
    return text

# Function to calculate a simple ATS score (example logic)
def calculate_ats_score(resume_text):
    # Example: Word match score (you can improve this logic)
    required_keywords = ['python', 'data', 'machine learning', 'analyst', 'developer']
    score = sum(1 for keyword in required_keywords if keyword.lower() in resume_text.lower())
    ats_score = min(100, score * 20)  # Max score is 100
    return ats_score

@app.route('/')
def home():
    return render_template('index.html')  # or send_file('index.html')

@app.route('/scan', methods=['POST'])
def scan():
    if 'resume' not in request.files:
        return "No file part"
    
    file = request.files['resume']
    if file.filename == '':
        return "No selected file"

    # Save the uploaded file
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)

    # Extract text from the resume based on file type
    resume_text = ''
    if file.filename.endswith('.pdf'):
        resume_text = extract_pdf_text(file_path)
    elif file.filename.endswith('.docx'):
        resume_text = extract_docx_text(file_path)

    if not resume_text:
        return "Failed to extract text from the resume"

    # Calculate ATS score
    ats_score = calculate_ats_score(resume_text)

    # Return result
    return render_template('result.html', ats_score=ats_score, resume_name=file.filename)

if __name__ == '__main__':
    app.run(debug=True)
